using System;
using Xunit;
using MedWeb;
using MedWeb.Controllers;
using MedWeb.Models;
using MedWeb.Repos;
using Moq;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace TestWeb
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            MedicineRepo medDto = new MedicineRepo();
            
            var controller = new HomeController(medDto);
            

            //Act  
            var data =  controller.Get();

            //Assert  
            Assert.IsType<OkObjectResult>(data);

        }
    }
}
