﻿using MedWeb.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using Newtonsoft.Json;
using Nancy.Json;
using Microsoft.AspNetCore.Http;

namespace MedWeb.Repos
{
    public interface IMedicineRepo
    {
        List<Medicine> GetMedicinesList();
        bool AddMedicineToList(Medicine med);
    }
    public class MedicineRepo : IMedicineRepo
    {
        public MedicineRepo()
        {

        }

        public List<Medicine> GetMedicinesList()
        {
            var mediList = new List<Medicine>();
            var med = new Medicine();
            med.Brand = "Test";
            med.ExpiryDate = new DateTime(2020,10,10);
            med.Name = "Test";
            med.Price = 20;
            med.Quantity = 20;
            med.Notes = "Test";
            mediList.Add(med);

            
            string filepath = "../MedWeb/Data/MedicineData.json";
            //deserialize JSON from file  
            string Json = System.IO.File.ReadAllText(filepath);

            JavaScriptSerializer ser = new JavaScriptSerializer();
            var personlist = ser.Deserialize<List<Medicine>>(Json);
            
            


            return personlist;
        }

        public bool AddMedicineToList(Medicine med)
        {
            var list = med;
           
            
            
            string json = JsonConvert.SerializeObject(list);
            string path = "../MedWeb/Data/MedicineData.json";

            if ((!File.Exists(path)))
            {
                //write string to file
                System.IO.File.WriteAllText(@"../MedWeb/Data/MedicineData.json", json);
            }
            else
            {
                string Json = System.IO.File.ReadAllText(path);

                JavaScriptSerializer ser = new JavaScriptSerializer();
                var medlist = ser.Deserialize<List<Medicine>>(Json);
                medlist.Add(med);
                var convertedJson = JsonConvert.SerializeObject(medlist, Formatting.Indented);

                System.IO.File.WriteAllText(@"../MedWeb/Data/MedicineData.json", convertedJson);
            }
            return true;
        }
    }
}
