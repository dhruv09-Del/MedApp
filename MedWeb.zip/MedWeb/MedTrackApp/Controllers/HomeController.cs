﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MedTrackApp.Models;
using System.Net.Http;


namespace MedTrackApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            IEnumerable<MedicineViewModel> medicineList = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44341/home/");
                //HTTP GET
                var responseTask = client.GetAsync("GetMedicineList");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IEnumerable<MedicineViewModel>>();
                    readTask.Wait();

                    medicineList = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..

                    medicineList = Enumerable.Empty<MedicineViewModel>();

                    ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                }
            }
            return View("Index",medicineList);

        }
        
        public IActionResult GetMedicine(string sidx, string sord, int page, int rows)
        {
            IEnumerable<MedicineViewModel> medicineList = null;

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44341/home/");
                //HTTP GET
                var responseTask = client.GetAsync("GetMedicineList");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IEnumerable<MedicineViewModel>>();
                    readTask.Wait();

                    medicineList = readTask.Result;
                }
                else //web api sent error response 
                {
                    //log response status here..

                    medicineList = Enumerable.Empty<MedicineViewModel>();

                    
                }
            }

            var products = medicineList;
            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;
            int totalRecords = products.Count();
            int totalPages = (int)Math.Ceiling((float)totalRecords / (float)pageSize);

            var data = products.OrderBy(x => x.Name)
                          .Skip(pageSize * (page - 1))
                          .Take(pageSize).ToList();

            var jsonData = new
            {
                total = totalPages,
                page = page,
                records = totalRecords,
                rows = data
            };
            

            return Json(jsonData,System.Web.Mvc.JsonRequestBehavior.AllowGet);
        }

        
        
        [HttpPost]
        public async Task<IActionResult> AddMedicine(MedicineViewModel vm)
        {
            MedicineViewModel vm1 = vm;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44341/home/");

                HttpResponseMessage response = await client.PostAsJsonAsync(
                "AddMedicineDetail", vm1);
                response.EnsureSuccessStatusCode();
            }
            return Ok();
        }
        

        [HttpGet]
        public IActionResult Edit(string id)
        {
            try
            {
                if (string.IsNullOrEmpty(id))
                {
                    return RedirectToAction("Index", "Home");
                }

                return View("Edit");
            }
            catch (Exception)
            {
                throw;
            }
        }

        [HttpPost]
        public IActionResult Delete(string id)
        {
            try
            {
                if (string.IsNullOrEmpty(id))
                {
                    return RedirectToAction("Index", "Home");
                }

                int result = 0;

                if (result > 0)
                {
                    return Json(data: true);
                }
                else
                {
                    return Json(data: false);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
